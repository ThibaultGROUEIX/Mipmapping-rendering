Informatique Graphique 3D et R�alit� Virtuelle 

Travaux Pratique

Rendu


Compilation : cd src; make -f Makefile.linux

Execution : ./main models/<fichier.off>

Contact: Tamy Boubekeur (tamy.boubekeur@telecom-paristech.fr)
